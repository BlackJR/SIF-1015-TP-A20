
#include<stdio.h>
#include<string.h>    //sizeof
#include<stdlib.h>    //strlen
#include<sys/socket.h>
#include<arpa/inet.h> //inet_addr
#include<unistd.h>    //write
#include<pthread.h> //for threading , link with lpthread
#include "gestionListeChaineeCVS.h"

//the thread function
void *connection_handler(void *);

int main(int argc , char *argv[])
{
    int socket_desc , client_sock , c;
    struct sockaddr_in server , client;

    pthread_t tid[1000];
	int i, nbThread = 0;


    //Create socket
    socket_desc = socket(AF_INET , SOCK_STREAM , 0);
    if (socket_desc == -1)
    {
        printf("Erreur lors de la création du socket");
    }
    puts("Socket créé");

    //Prepare the sockaddr_in structure
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = INADDR_ANY;
    server.sin_port = htons( PORT );

    //Bind
    if( bind(socket_desc,(struct sockaddr *)&server , sizeof(server)) < 0)
    {
        //print the error message
        perror("bind failed. Error");
        return 1;
    }
    puts("bind done");
     
    //Listen
    listen(socket_desc , 3);
     
    //Accept and incoming connection
    puts("Waiting for incoming connections...");
    c = sizeof(struct sockaddr_in);
     
	
    while( (client_sock = accept(socket_desc, (struct sockaddr *)&client, (socklen_t*)&c)) )
    {
        puts("Connection accepted");
        // we need to create a lot of threads ids, bc they will be a lot of incoming connexions;
        if( pthread_create( &tid[nbThread++] , NULL ,  connection_handler , (void*) &client_sock) < 0)
        {
            perror("could not create thread");
            return 1;
        }
         
        //Now join the thread , so that we dont terminate before the thread
        //pthread_join( thread_id , NULL);
        puts("Handler assigned");
    }
    for(i=0; i<nbThread;i++){
		pthread_join(tid[i], NULL);
	}
     
    if (client_sock < 0)
    {
        perror("accept failed");
        return 1;
    }
     
    return 0;
}
 
/*
 * This will handle connection for each client
 * */
void *connection_handler(void *socket_desc)
{
    //Get the socket descriptor
    int sock = *(int*)socket_desc;
    int read_size;
    char *message , client_message[400];
    struct Info_FIFO_Transaction my_data;
    struct Info_FIFO_Transaction client_response;
     
    //Send some messages to the client
    message = "Greetings! I am your connection handler\n";
    my_data.pid_client = 2323;
    strcpy(my_data.transaction, message);
    write(sock , &my_data , sizeof(my_data));
     
    message = "Now type something and i shall repeat what you type \n";
    strcpy(my_data.transaction, message);
    write(sock , &my_data , sizeof(my_data));
     
    //Receive a message from client
    while( (read_size = read(sock , &client_response , sizeof(client_response))) > 0 )
    {
        //end of string marker
		
		//Send the message back to client
        write(sock , &client_response , sizeof(client_response));
        printf("From CLIENT : %s \n",client_response.transaction);
        //write(sock , client_message , sizeof(client_message));
		
		//clear the message buffer
		//memset(client_message, 0, 2000);
    }
     
    if(read_size == 0)
    {
        puts("Client disconnected");
        fflush(stdout);
    }
    else if(read_size == -1)
    {
        perror("recv failed");
    }
         
    return 0;
} 