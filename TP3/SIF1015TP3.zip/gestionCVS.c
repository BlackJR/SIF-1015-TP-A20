//#########################################################
//#
//# Titre : 	Utilitaires Liste Chainee et CVS LINUX Automne 11
//#				SIF-1015 - Système d'exploitation
//#				Université du Québec à Trois-Rivières
//#
//# Auteur : 	Ulrich YOUGBARE
//#	Date :		Decembre 2020
//#
//# Langage : 	ANSI C on LINUX (Debian)
//#
//#######################################

#include "gestionListeChaineeCVS.h"

//Pointeur de tête de liste
extern struct noeud* head;
//Pointeur de queue de liste pour ajout rapide
extern struct noeud* queue;

extern int nbThreadAMLSO;

extern sem_t semH;
extern sem_t semQ;
extern sem_t semConsole;
extern sem_t semNBThreadAMLSO;

//#######################################
//#
//# Affiche une série de retour de ligne pour "nettoyer" la console
//#
void cls(void){
	printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
	}

//#######################################
//#
//# Affiche un messgae et quitte le programme
//#
void error(const int exitcode, const char * message){
	printf("\n-------------------------\n%s\n",message);
	exit(exitcode);
	}

//#######################################
//#
//# Chargement de la BD binaire
//#
void loadFich(const char* sourcefname){
	
	//Initialisation des pointeurs
	head = NULL;
	queue = NULL;


	const char tligne[100];
	int noligne=0;

	//Ouverture du fichier source en mode "rt" : [r]ead [t]ext
	FILE *f;
	f = fopen(sourcefname, "rt");
	if (f==NULL)
		return;

	//Ajout des éléments extraits du fichier source
	
	while(!feof(f)){
		fgets(tligne, 100, f);
		addItemNONCONCURRENT(noligne++, tligne);
		}

 }

//#######################################
//#
//# Enregistre le contenu de la liste chaînée dans un fichier texte
//#
void saveItems(struct infoSAVE* param){
	
	char sourcefname[100];
	struct noeud * ptr = NULL;
	
	strcpy(sourcefname,(const char*)param->nomFichier);
	free(param);
	
	sem_wait(&semNBThreadAMLSO);
	    nbThreadAMLSO++;
	sem_post(&semNBThreadAMLSO);
	
	sem_wait(&semH);
	sem_wait(&semQ);

	if(head != NULL)
		ptr = head;	// premier element
	else{ // liste vide 
		sem_wait(&semNBThreadAMLSO);
		    nbThreadAMLSO--;
		sem_post(&semNBThreadAMLSO);
		sem_post(&semQ);
		sem_post(&semH);
		return;	
	}
	FILE *f;
	char nomC[255];
	char nomTXT[255];
	char command[255];
	char *ptrC;

	strcpy(nomC,sourcefname);
	strcpy(nomTXT, sourcefname);
	ptrC = strrchr(nomTXT,'.');
	strcpy(ptrC,".txt");
	ptrC = strrchr(nomC,'.');
	strcpy(ptrC,".c");

	//Ouverture du fichier en mode "wt" : [w]rite [t]ext

 	f= fopen(nomTXT, "wt");

	
	if (f==NULL)
		error(2, "saveItems: Erreur lors de l'ouverture du fichier pour écriture en mode texte.");

	while (ptr!=NULL){

		//Écriture des données
		fprintf(f,"%s\n",ptr->ligne.ptrligne);
		
		//Déplacement du pointeur
		ptr = ptr->suivant;
		}
	
	//Fermeture du fichier
	fclose(f);

	// Passage de .txt a .c
	sprintf(command,"mv %s %s",nomTXT,nomC);
	system(command);
	
	sem_wait(&semNBThreadAMLSO);
	    nbThreadAMLSO--;
	sem_post(&semNBThreadAMLSO);
	sem_post(&semQ);
	sem_post(&semH);
	
}

//#######################################
//#
//# Execute le fichier source .c , et envoit le retour au client.
//#
void executeFile(struct infoEXE* param){

	char nomFichier[100];
	int socket_client;

	strcpy(nomFichier,(const char*)param->nomFichier);
	socket_client = param->socket_client;

	free(param);

	char command[100];
	char nameC[100];
	char buffer[128];

	FILE *f, *commandOutput;

	//Ouverture du fichier MakeCVS en mode "wt" : [w]rite [t]ext
	f = fopen("MakeCVS", "wt");
	if (f==NULL){
		error(2, "ExecuteFile: Erreur lors de l'ouverture du fichier pour écriture en mode texte.");
	}
	
	strcpy(nameC,nomFichier);
	fprintf(f,"fichCVSEXE: %s\n",nomFichier);
	fprintf(f,"\tgcc -o fichCVSEXE %s\n",nomFichier);

	//Fermeture du fichier
	fclose(f);

	// make du fichier MakeCVS
	sprintf(command, "make -f MakeCVS");
	system(command);

	// execution du fichier compilé fichCVSEXE
	sprintf(command, "./fichCVSEXE");
	
	// on va récupérer l'output de la commande et le renvoyer au client
	commandOutput = popen(command,"r");
    if (!commandOutput) {
        fprintf(stderr, "Erreur lors de la récupération du résultat d'exécution.\n");
        //exit(EXIT_FAILURE);
    }
	while (fgets(buffer, sizeof buffer, commandOutput) != NULL) {
        writeOnClientSocket(socket_client, buffer);
    }

	system(command);
}


/*
 * Cette fonction va traiter la connexion à chaque client
 * */
void *clientConnexionHandler(void *socket_desc)
{
    //Récupération du socket
    int sock = *(int*)socket_desc;
    int read_size;
    char *tok, *sp;
    struct Info_FIFO_Transaction transactionClient;
	pthread_t requestThreadId[1000];
	int i, nbThread = 0;
     
    //Réception d'un message du client
    while( (read_size = read(sock , &transactionClient , sizeof(transactionClient))) > 0 )
    {
        if (read_size > 0) {
            
            printf("Transaction du client : %s \n\n ", transactionClient.transaction);
			
			//Extraction du type de transaction
			tok = strtok_r(transactionClient.transaction, " ", &sp);


            //Branchement selon le type de transaction
			switch(tok[0]){
				case 'A':
				case 'a':{
					//Extraction des paramètres
					int noligne = atoi(strtok_r(NULL, " ", &sp));
					char *tligne = strtok_r(NULL, "\n", &sp);
					
					struct infoADD *ptr = (struct infoADD*) malloc(sizeof(struct infoADD));
					ptr->noligne = noligne;
					strcpy(ptr->tligne,(const char *)tligne);
					
					//Appel de la fonction associée
					pthread_create(&requestThreadId[nbThread++], NULL, (void *)addItem, ptr);
					break;
					}
				case 'E':
				case 'e':{
					//Extraction du paramètre
					int noligne = atoi(strtok_r(NULL, " ", &sp));
					
					struct infoREMOVE *ptr = (struct infoREMOVE*) malloc(sizeof(struct infoREMOVE));
					ptr->noligne = noligne;
					
					//Appel de la fonction associee
					pthread_create(&requestThreadId[nbThread++], NULL, (void *)removeItem, ptr);
					break;
					}
				case 'M':
				case 'm':{
					//Extraction des paramètres
					int noligne = atoi(strtok_r(NULL, " ", &sp));
					char *tligne = strtok_r(NULL, "\n", &sp);
					
					struct infoMODIFY *ptr = (struct infoMODIFY*) malloc(sizeof(struct infoMODIFY));
					ptr->noligne = noligne;
					strcpy(ptr->tligne,(const char *)tligne);
					
					//Appel de la fonction associee
					pthread_create(&requestThreadId[nbThread++], NULL, (void *)modifyItem, ptr);
					break;
					}
				case 'L':
				case 'l':{
					//Extraction des paramètres
					int nstart = atoi(strtok_r(NULL, "-", &sp));
					int nend = atoi(strtok_r(NULL, " ", &sp));
					
					struct infoLIST *ptr = (struct infoLIST*) malloc(sizeof(struct infoLIST));
					ptr->start = nstart;
					ptr->end = nend;
					ptr->socket_client = sock;
					//Appel de la fonction associee
					pthread_create(&requestThreadId[nbThread++], NULL, (void *)listItems, ptr);
					break;
					}
				case 'S':
				case 's':{
					//Extraction des paramètres
					char *nomfich = strtok_r(NULL, " ", &sp);
					
					struct infoSAVE *ptr = (struct infoSAVE*) malloc(sizeof(struct infoSAVE));
					strcpy(ptr->nomFichier,(const char *)nomfich);

					//Appel de la fonction associee
					pthread_create(&requestThreadId[nbThread++], NULL, (void *)saveItems, ptr);
					break;
					}
				case 'X':
				case 'x':{
					//Appel de la fonction associée
					char *nomfich = strtok_r(NULL, " ", &sp);
					
					struct infoEXE *ptr = (struct infoEXE*) malloc(sizeof(struct infoEXE));
					strcpy(ptr->nomFichier,(const char *)nomfich);
					ptr->socket_client = sock;

					//Appel de la fonction associee
					pthread_create(&requestThreadId[nbThread++], NULL, (void *)executeFile, ptr);
					break;
					}
				default:{
					//Au cas où la commande ne fonctionne pas
					writeOnClientSocket(sock,"Commande inconnue.");
					}
			}
        }
	
		bzero(&transactionClient.transaction, sizeof(transactionClient));
	}
	for(i=0; i<nbThread;i++){
		pthread_join(requestThreadId[i], NULL);
	}

    if(read_size == 0)
    {
        puts("Client déconnecté");
        fflush(stdout);
    }
    else if(read_size == -1)
    {
        perror("Réception impossible !");
    }
    return 0;
} 

//#######################################
//#
//# fonction utilisée par les threads de transactions
//#
void readTrans(){
	
	int socket_desc , client_sock , c;
    struct sockaddr_in server , client;

    pthread_t requestThreadId[1000];
	int i, nbThread = 0;


    //Creation du socket
    socket_desc = socket(AF_INET , SOCK_STREAM , 0);
    if (socket_desc == -1)
    {
        printf("Erreur lors de la création du socket");
    }
    //puts("Socket créé");

    //affectation des adresses ip
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = INADDR_ANY;
    server.sin_port = htons( PORT );

    //Binding ...
    if( bind(socket_desc,(struct sockaddr *)&server , sizeof(server)) < 0)
    {
        perror("bind failed. Error");
        exit(1);
    }
    //puts("bind done");
     
    //Ecoute..
    listen(socket_desc , 3);
	printf("\n\n###############################################################################\n");
	printf(" Serveur lancé avec le pid numéro %d. En attente de connexion entrante...\n", getpid());
	printf("###############################################################################\n\n");
     
    //Accept and incoming connection
    c = sizeof(struct sockaddr_in);
     
    while( (client_sock = accept(socket_desc, (struct sockaddr *)&client, (socklen_t*)&c)) )
    {
		struct sockaddr_in* pV4Addr = (struct sockaddr_in*)&client;
		struct in_addr ipAddr = pV4Addr->sin_addr;
		char clientIP[INET_ADDRSTRLEN];
		inet_ntop( AF_INET, &ipAddr, clientIP, INET_ADDRSTRLEN );

        printf("Acceptation de %s ... ",inet_ntoa(client.sin_addr));
        if( pthread_create( &requestThreadId[nbThread++] , NULL ,  clientConnexionHandler , (void*) &client_sock) < 0)
        {
            perror("Erreur lors de la création des threads");
            exit(1);
        }
         
        printf("Accepté !\n\n");
    }
    for(i=0; i<nbThread;i++){
		pthread_join(requestThreadId[i], NULL);
	}
     
    if (client_sock < 0)
    {
        perror("accept failed");
		close(client_sock);
        exit(1);
    }
}


