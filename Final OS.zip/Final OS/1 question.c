//structure de donnee des fichier a recevoir
struct arguments_x {
	char nom_dufichier[100];
	char type[100];
};
//fonction utilisee par les threads de transactions	
	case 'x':
	case 'X':
	{
		//Definition de la structure des parametres du thread ajout
		struct arguments_x* args = (struct arguments_x*)malloc(sizeof(struct arguments_x));
		strcpy(args->nom_dufichier, ptrnom_dufichier);

		struct stat stat;
		char *type, *readok;

		Stat(arguments_x[1], &stat);
		if (S_ISREG(stat.st_mode))
			type = "regular";
		else if (S_ISDIR(stat.st_mode))
			type = "directory";
		else
			type = "other";
		if ((stat.st_mode & S_IRUSR))
			readok = "yes";
		else
			readok = "no";

		strcpy(args->type, type);

		//Creation du thread
		pthread_t thread;
		if (pthread_create(&thread, NULL, reponseText, (void *)arguments_x) != 0) {
			=
				printf("Erreur creation thread\n");
		}

//COTE SERVEUR

int main(int argc, char* argv[]) {
	// Initialisation du mutex de la console
	sem_init(&mutexConsole, 0, 1);
	listen(server_sockfd, 5);
	while (1) {
		client_len = sizeof(adresClient);
		client_sockfd = accept(server_sockfd, (struct sockaddr *)&adresClient, &client_len);
		pthread_t threadClient;
		if (pthread_create(&threadClient, NULL, ReadClient, (void *)&client_sockfd) != 0) {
			printf("Erreur creation thread\n");
		}
	}
	//Structure de réception
	// Sockets
	int server_sockfd, client_sockfd;
	int server_len, client_len;
	struct sockaddr_in serveur_addresse;
	struct sockaddr_in adresClient;

	server_sockfd = socket(AF_INET, SOCK_STREAM, 0);
	serveur_addresse.sin_family = AF_INET;
	serveur_addresse.sin_addr.s_addr = inet_addr("197.254.250.1");
	serveur_addresse.sin_port = 8080;
	server_len = sizeof(serveur_addresse);
	bind(server_sockfd, (struct sockaddr*)&serveur_addresse, server_len);
	//Initialisation des pointeurs
	tete = NULL;
	queue = NULL;
	
	
	//Fin du programme
	exit(0);
}

void* ReadClient(void * arg) {
	struct Info_Transaction currTrans;
	int client_sockfd = *((int*)arg);
	int quit = 1;
	int read_res = 0;
	while (quit) {
		read_res = read(client_sockfd, &currTrans, sizeof(currTrans));
		currTrans.client_sockfd = client_sockfd;
		if (read_res > 0) {
			printf("Requete recue: %s\n", currTrans.transaction);
			// Envoyer la structure à la fonction de traitement de la transaction
			readTransCHAT(currTrans);
		}
	}

	return NULL;

}
