//cote client

char nom_fichier[NAME_LEN];
printw("%s", "File name => ");
getstr(name);

currTrans.client_sockfd = -1;
sprintf(currTrans.transaction, "A %s", name);

sockfd = socket(AF_INET, SOCK_STREAM, 0);

adresse.sin_family = AF_INET;
adresse.sin_addr.s_addr = inet_addr("197.128.0.1");
adresse.sin_port = 8080;
len = sizeof(adresse);
resultat = connect(sockfd, (struct sockaddr*)&adresse, len);
if (resultat == -1) {
	exit(1);
}
/*//*/*/*/*/*/*/*/*//*/*/*///////////////////////////////////////////
void * ecouteServeur(void* args) {
	// On récupère les paramètres
	struct structEcouteParams* params = (struct structEcouteParams*) args;
	// sil donne une structure
	struct Info_Transaction readTrans;

	int read_res;
	while (1) {
		read_res = read(sockfd, &readTrans, sizeof(readTrans));
		if (read_res > 0) {

			char  *spare;
			tok = strtok_r(readTrans.transaction, " ", &spare);
			// Si c'est une transmission
			switch (tok[0]) {
			case 'x':
			case 'X': {
				// Extraire les informations du fichier
				char *Fichier = strtok_r(NULL, " ", &spare);


				sem_wait(&semReceiveWin);
				// Écrire ce qu'on recoit dans  notre fenetre
				wprintw(params->receive_window_ptr, "%s\n", nomdenvoie);
				wrefresh(params->receive_window_ptr);
				sem_post(&semReceiveWin);
				break;
			}
            /*//*/*/*/*/*/*/*/*//*/*/*///////////////////////////////////////////
write(sockfd, &currTrans, sizeof(currTrans));

// Ouverture de chacune des windows : Envoi et réception
receive_window_ptr = newwin(24, 48, 3, 3);
wattron(receive_window_ptr, COLOR_PAIR(3));
// Activation du scrolling
scrollok(receive_window_ptr, 1);
//refresh curses windows and lines 
wrefresh(receive_window_ptr);

send_window_ptr = newwin(25, 60, 18, 2);
wattron(send_window_ptr, COLOR_PAIR(1));
box(send_window_ptr, '||', '--');

wrefresh(send_window_ptr);
// Initialisation du semaphore de la window de réception
sem_init(&semReceiveWin, 0, 1);

struct structEcouteParams* params = (struct structEcouteParams*)malloc(sizeof(struct structEcouteParams));
params->receive_window_ptr = receive_window_ptr;
//starts a new thread in the calling
       //process
pthread_create(&listen_thread, NULL, ecouteServeur, (void*)params);






