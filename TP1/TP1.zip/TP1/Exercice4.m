﻿clear all;clc;
%***************************
%Fichier: Exercice 4 - TP1
%
%Auteurs: Aicha Gansonre et Omer Ayad
%Création: 2019-09-10
%Modifications
%***************************

%L'utilisateur saisit les informations demandees:
nom = input('Veuillez entrer votre nom de famille','s')
prenom = input('Veuillez entrer votre prenom.','s')
genre = input('Veuillez entrer votre genre (Mou F).','s')
dates = input('Veuillez entrer votre date de naissance [JJ MM AAAA]')
emploi = input('Veuillez entrer votre emploi:','s')
%Les 3 premieres lettres de l'emploi sont ABC:
ABC = upper(emploi(1:3))
%Les 3 premieres lettres du nom sont DEF:
DEF = upper(nom(1:3))
%La premiere lettre du prenom est G:
G = upper(prenom(1,1))
%Un chiffre aleatoire entre 1 et 9 correspond a 1:
c1 = mod(1+rand*8,100)
%On converti 1 en chaine de caractere:
c1=num2str(c1,'%0.2d')
%On defini taille comme la longueur du prenom:
taille= length(prenom)
%On cherche a definir deux comme les 2 derniers chiffres de l'annee de naissance:
annee=num2str(dates(1,3))
deux=str2num(annee(3:4))
%23 cest le jour de naissance+ la valeur ASCII du genre-30:
c23= mod(dates(1,1)+ double(genre)- 30,100)
c23=num2str(c23,'%0.2d')
%On a Ef qui sont les deux dernieres lettres du prenom a l'envers:
Ef=[upper(prenom(1,taille)) prenom(1,taille-1)]
%Gh est la premiere et la derniere lettre du prenom:
Gh=[upper(prenom(1,1)) prenom(1,taille)]
%On a 45 qui est la valeur ASCII de la deuxieme lettre du prenom en majuscule moins les chiffres du mois de naissance
c45=abs(mod(double(upper((prenom(1,2)))- dates(1,2),100)
c45=num2str(c45,'%0.2d')
%On a 67 qui sont les deux derniers chiffres de l'annee de naissance moins un entier entre 1 et 20
c67=abs(mod(deux-( 1+rand*19),100))
c67=num2str(c67,'%0.2d')

%On salue l'utilisateur
fprintf('** Bonjour %s %s **',prenom,nom)
%On affiche l'identifiant sous le format ABCDEFG123
fprintf('Votre identifiant est %s%s%s%s%s :',ABC,DEF,G,c1,c23)
%On affiche le mot de passe sous la forme EfGh4567:
fprintf('Votre mot de passe est %s%s%s%s : ',Ef,Gh,c45,c67)
fprintf('*************************')