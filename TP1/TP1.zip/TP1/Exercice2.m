﻿clear all;clc;
%*****************
% Fichier: Exercice 2_TP1
% Auteurs:Aicha Gansonre et Omer Ayad
%Création: 2019-09-10
%Modifications
%******************

%On change le format de la fenetre de commande:
format shortG
    %On demande a l'utilisateur de saisir les vecteurs:
T1 = input('Veuillez saisir le premier vecteur:');
T2 = input('Veuillez saisir le deuxième vecteur:');
T3 = input('Veuillez saisir le troisième vecteur:');

%On les affiche avec disp
fprintf('Les vecteurs sont: \n')
disp(T1)
disp(T2)
disp(T3)
%On les modifie avec le facteur de securite de 20% a l'arriere:
T1(1,3:4) = T1(1,3:4)*(1+0.2)
T2(1,3:4) = T2(1,3:4)*(1+0.2)
T3(1,3:4) = T3(1,3:4)*(1+0.2)

%On affiche les nouveaux vecteurs:
fprintf('Les vecteurs deviennent:\n')
disp(T1)
disp(T2)
disp(T3)
indice = 2;
%On indique ou la voiture doit entrer:
fprintf('La voiture doit rentrer aux puits au point de contrôle %d',indice)
