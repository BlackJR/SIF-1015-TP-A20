﻿clear all;clc;
%***************************
%Fichier: Exercise 1 - TP1
%Exemple sur le script
%Auteurs: Aicha Gansonre et Omer Ayad
%Création: 2019-09-10
%Modifications
%***************************

%On demande a l'utilisater le volume max et la surface minimale:
Vmax = input('Donner le volume maximal du réservoir(en m^3):');
Smin = input('Donner la surface minimal du réservoir(en m^2):');
%On demande le rayon a l'utilisateur:
r = input('Donner la valeur du rayon(en m):');
%On calcule le Volume et la surface des deux demi-spheres:
Vs = (4*pi*r^3)/3;
Ss = 4*pi*r^2;
%On calcule la hauteur maximale et minimale:
Amax = (Vmax-Vs)/(pi*r^2);
Amin = (Smin-Ss)/(2*pi*r); 
%On affiche les resultats:
fprintf('Resultats: \n La hauteur minimale est %0.2f m et la hauteur maximale est %0.2f m.',Amin,Amax)