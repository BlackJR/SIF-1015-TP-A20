﻿clear all;clc;
%***************************
%Fichier: Exercice 3 - TP1
%Exemple sur le script
%Auteurs: Aicha Gansonre et Omer Ayad
%Création: 2019-09-10
%Modifications
%***************************

%Changement du format  d’affichage de la fenêtre:
format shortG
    
%Construction de la matrice A avec le fonction ones et diag:
A= 4*ones(4)+diag([14,12,10,8])+diag([1,2],2);
disp(A)

%Construction de la matrice B avec les bornes et la raison:
B=transpose([2:3:11;14:-1:11;11:14:53]);
disp(B)

%Construction de la matrice C valeur par valeur:
C= [5 2 4 13 29];
disp(C)

%Construction de la matrice D:
D= (A*B)/5;
disp(D)
%Division des lignes paires de D par 2:
D([2:4],:)= D([2:4],:)/2;
%Suppression de la  dernière colonne de la matrice B:
B(:,3)=[];
%Concatener D et B pour donner E:
E=[D B];
disp(E)

%Afficher le septieme elemnt de la matrice E:
fprintf('Le septieme element de la matrice E est %0.2f \n', E(3,2))
%Afficher les elements de la 1ere et derniere ligne de E:
disp(E([1:end],:))

%On cree F avec des entiers aleatoires entre 10 et 99:
F= randi([10,99],5,4);
disp(F)
%On ajoute une colonne de zero a la matrice F avec la fonction zeros:
F(:,5)=zeros(5,1);
%On remplace la diagonale de F par le vecteur C:
F(1:6:end)= C;
%On forme G en supprimant la premiere ligne de F:
G= F([2:5],:);
disp(G)
%On multiplie G par E element par element pour former H:
H= E.*G;
disp(H)
%On forme I qui contient la moyenne de chaque colonne de H
I=sum(H)/size(H,1);
disp(I)